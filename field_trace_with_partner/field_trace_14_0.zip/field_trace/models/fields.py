from odoo import api, fields, models, tools

class IrModelField(models.Model):
    _inherit = 'ir.model.fields'

    trace = fields.Boolean('Enable Ordered Tracking',default=False)

    def _reflect_field_params(self, field, model_id):
        vals = super(IrModelField, self)._reflect_field_params(field, model_id)
        trace_f = self.env['ir.model.fields'].search([('model_id', '=', model_id),('name','=',field.name),('trace','=',True)])
        trace = False
        if trace_f and trace_f.trace == True:
            vals['trace'] = True
            # print('\n----------------- this is vals : ',vals)
            # trace = True
        else:
            # trace = False
            vals['trace'] = False
        return vals

    def _instanciate_attrs(self, field_data):
        attrs = super(IrModelField, self)._instanciate_attrs(field_data)
        if attrs and field_data.get('trace'):
            attrs['trace'] = field_data['trace']
            print('--------------------------- instanciate attrs : ',attrs)
            print('--------------------------- field_data 11 : ',field_data)
        return attrs


    @api.onchange('trace')
    def trace_field(self):
        self.state = 'manual'
        self.env.cr.execute('''update ir_model_fields set "state" = 'manual' where id = %(id)s''',{'id' : self._origin.id})
        print('--------- track : ',self.tracking)
        print('---------- this is state : ',self.state)
        # self.state = 'base'

    def write(self,vals):
        # self.trace_field()
        print('---------- this is vals : ',vals,self.state)
        # self.update({'state' : 'manual'})
        # vals['state'] = 'manual'
        # self.env.cr.execute('''update ir_model_fields set "state" = 'manual' where id = %(id)s''',{'id' : self.id})
        print('---------- this is vals : --------//',vals,self.state)
        result = super(IrModelField, self).write(vals)
        # self.env.cr.execute('''update ir_model_fields set "state" = 'base' where id = %(id)s''',{'id' : self.id})
        print('---------- this is vals jj : --------',vals,self.state)
        print('---------- this result : --------',result)
        # if self.trace:
        #     result['tracking'] = 100
        # else:
        #     result['tracking'] = False
        if vals['trace'] == True:
            # self.env.cr.execute('''update ir_model set "state" = 'base' where id = %(id)s''',{'id' : self._origin.model_id.id})
            self.env.cr.execute('''update ir_model_fields set "state"='base', "trace"='t' where id = %(id)s''',{'id' : self._origin.id})
        else:
            self.env.cr.execute('''update ir_model_fields set "state"='base', "trace"='f' where id = %(id)s''',{'id' : self._origin.id})
        return result

    

class MailThread(models.AbstractModel):
    _inherit = 'mail.thread'



    @tools.ormcache('self.env.uid', 'self.env.su')
    def _get_tracked_fields(self):
        """ Return the set of tracked fields names for the current model. """
        res = super(MailThread, self)._get_tracked_fields()
        print('------------ this is mail thread self : ',self,self.env.context)
        # print('\n\n\n\n------------ this is mail thread self  field: ',self._model)
        # print ('>>>>>>>>>>>>>',res)
        filter_fields = self.env['ir.model.fields'].search([('trace','=',True)])
        custom_fields = {
            name
            for name, field in self._fields.items()
            if getattr(field, 'track_visibility', None) or getattr(field, 'trace', True)
        }

        print ('.................. res : ',res)
        a = res and set( list(res) + list(set(self.fields_get(custom_fields))) )
        # print ('..................',res)
        return a


    def _message_create(self, values_list):
        record = super(MailThread, self)._message_create(values_list=values_list)
        # print('\n\n\n\n\n\n\n\n\n\n\n\n\n\n------------------------- this is record : ',record)
        # print('\n------------------------- this is record : ',record.partner_ids,record.author_id)
        if record.partner_ids and record.model == 'sale.order':
            record.write({'author_id':[r for r in record.partner_ids][0]})
        return record


class BaseModel(models.AbstractModel):
    _inherit = 'base'

    def _mail_track(self, tracked_fields, initial):
        result, f_ids = super(BaseModel, self)._mail_track(tracked_fields=tracked_fields,initial=initial)
        # res = list(result)
        # print('---------------------- this is result : ',result)
        # print('\n\n\n\n\n\n\n\n\n---------------------- this is f_id : ',f_ids)
        data = []
        f_data = []
        for i,j in zip(result,f_ids):
            if j[2].get('field_type') != 'datetime' and j[2].get('trace') == True:
                data.append(j)
                f_data.append(i)
        f_ids = data
        result = set(f_data)
        # res_data = tuple(res)
        # print('\n\n\n\n\n\n------------------------- res_data : ',res_data)
        # print('---------------------- this is fields items : ',tracked_fields.items())
        # print('\n\n\n\n---------------------- this is fields items  --------------\n\n\n\n\n: ',tracked_fields)
        return result, f_ids


class MailTracking(models.Model):
    _inherit = 'mail.tracking.value'

    trace = fields.Boolean(default=False)

    @api.model
    def create_tracking_values(self, initial_value, new_value, col_name, col_info, tracking_sequence, model_name):
        attrs = super(MailTracking, self).create_tracking_values(initial_value=initial_value,new_value=new_value,col_name=col_name,col_info=col_info,tracking_sequence=tracking_sequence,model_name=model_name)
        field = self.env['ir.model.fields']._get(model_name, col_name)
        print('- in ----------------------------------------------------------------------------------------------',field)
        if attrs:
            attrs['trace'] = True if field.trace == True else False
            print('-------------- this is attrs : ',attrs)
            print('-------------- this is attrs dol_info 0: ',col_info)
        else:
            print('----------------------- nothing in attrs : ')

        return attrs

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def find_current_partner(self):
        print('------------------------------------------------ this is sale order recordset : ',self)
        return self
